﻿namespace QLTV_GUI
{
    partial class CapNhatSach
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.bt_thoat = new System.Windows.Forms.Button();
            this.bt_capNhat = new System.Windows.Forms.Button();
            this.label11 = new System.Windows.Forms.Label();
            this.tb_maSach = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.tb_soLuong = new System.Windows.Forms.TextBox();
            this.cb_theLoai = new System.Windows.Forms.ComboBox();
            this.tb_tinhTrang = new System.Windows.Forms.TextBox();
            this.tb_triGia = new System.Windows.Forms.TextBox();
            this.tb_nhaXuatBan = new System.Windows.Forms.TextBox();
            this.tb_namXuatBan = new System.Windows.Forms.TextBox();
            this.tb_tacGia = new System.Windows.Forms.TextBox();
            this.tb_tenSach = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // bt_thoat
            // 
            this.bt_thoat.BackColor = System.Drawing.Color.Tomato;
            this.bt_thoat.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.bt_thoat.ForeColor = System.Drawing.SystemColors.Control;
            this.bt_thoat.Location = new System.Drawing.Point(436, 384);
            this.bt_thoat.Name = "bt_thoat";
            this.bt_thoat.Size = new System.Drawing.Size(110, 50);
            this.bt_thoat.TabIndex = 95;
            this.bt_thoat.Text = "THOÁT";
            this.bt_thoat.UseVisualStyleBackColor = false;
            // 
            // bt_capNhat
            // 
            this.bt_capNhat.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.bt_capNhat.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.bt_capNhat.ForeColor = System.Drawing.SystemColors.Control;
            this.bt_capNhat.Location = new System.Drawing.Point(221, 384);
            this.bt_capNhat.Name = "bt_capNhat";
            this.bt_capNhat.Size = new System.Drawing.Size(110, 50);
            this.bt_capNhat.TabIndex = 94;
            this.bt_capNhat.Text = "CẬP NHẬT";
            this.bt_capNhat.UseVisualStyleBackColor = false;
            this.bt_capNhat.Click += new System.EventHandler(this.bt_capNhat_Click);
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label11.ForeColor = System.Drawing.SystemColors.MenuHighlight;
            this.label11.Location = new System.Drawing.Point(153, 20);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(393, 31);
            this.label11.TabIndex = 93;
            this.label11.Text = "CẬP NHẬT THÔNG TIN SÁCH";
            // 
            // tb_maSach
            // 
            this.tb_maSach.Location = new System.Drawing.Point(343, 65);
            this.tb_maSach.Name = "tb_maSach";
            this.tb_maSach.Size = new System.Drawing.Size(110, 20);
            this.tb_maSach.TabIndex = 92;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(264, 68);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(51, 13);
            this.label10.TabIndex = 91;
            this.label10.Text = "Mã sách:";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(140, 303);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(52, 13);
            this.label9.TabIndex = 90;
            this.label9.Text = "Số lượng:";
            // 
            // tb_soLuong
            // 
            this.tb_soLuong.Location = new System.Drawing.Point(221, 300);
            this.tb_soLuong.Name = "tb_soLuong";
            this.tb_soLuong.Size = new System.Drawing.Size(83, 20);
            this.tb_soLuong.TabIndex = 89;
            // 
            // cb_theLoai
            // 
            this.cb_theLoai.FormattingEnabled = true;
            this.cb_theLoai.Location = new System.Drawing.Point(391, 200);
            this.cb_theLoai.Name = "cb_theLoai";
            this.cb_theLoai.Size = new System.Drawing.Size(155, 21);
            this.cb_theLoai.TabIndex = 88;
            // 
            // tb_tinhTrang
            // 
            this.tb_tinhTrang.Location = new System.Drawing.Point(221, 335);
            this.tb_tinhTrang.Name = "tb_tinhTrang";
            this.tb_tinhTrang.Size = new System.Drawing.Size(326, 20);
            this.tb_tinhTrang.TabIndex = 87;
            // 
            // tb_triGia
            // 
            this.tb_triGia.Location = new System.Drawing.Point(391, 300);
            this.tb_triGia.Name = "tb_triGia";
            this.tb_triGia.Size = new System.Drawing.Size(155, 20);
            this.tb_triGia.TabIndex = 86;
            // 
            // tb_nhaXuatBan
            // 
            this.tb_nhaXuatBan.Location = new System.Drawing.Point(221, 241);
            this.tb_nhaXuatBan.Name = "tb_nhaXuatBan";
            this.tb_nhaXuatBan.Size = new System.Drawing.Size(326, 20);
            this.tb_nhaXuatBan.TabIndex = 84;
            // 
            // tb_namXuatBan
            // 
            this.tb_namXuatBan.Location = new System.Drawing.Point(221, 200);
            this.tb_namXuatBan.Name = "tb_namXuatBan";
            this.tb_namXuatBan.Size = new System.Drawing.Size(83, 20);
            this.tb_namXuatBan.TabIndex = 83;
            // 
            // tb_tacGia
            // 
            this.tb_tacGia.Location = new System.Drawing.Point(221, 160);
            this.tb_tacGia.Name = "tb_tacGia";
            this.tb_tacGia.Size = new System.Drawing.Size(325, 20);
            this.tb_tacGia.TabIndex = 82;
            // 
            // tb_tenSach
            // 
            this.tb_tenSach.Location = new System.Drawing.Point(221, 119);
            this.tb_tenSach.Name = "tb_tenSach";
            this.tb_tenSach.Size = new System.Drawing.Size(326, 20);
            this.tb_tenSach.TabIndex = 81;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(139, 338);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(58, 13);
            this.label8.TabIndex = 80;
            this.label8.Text = "Tình trạng:";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(325, 303);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(39, 13);
            this.label7.TabIndex = 79;
            this.label7.Text = "Trị giá:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(138, 244);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(74, 13);
            this.label5.TabIndex = 77;
            this.label5.Text = "Nhà xuất bản:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(139, 203);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(76, 13);
            this.label4.TabIndex = 76;
            this.label4.Text = "Năm xuất bản:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(139, 163);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(46, 13);
            this.label3.TabIndex = 75;
            this.label3.Text = "Tác giả:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(325, 203);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(48, 13);
            this.label2.TabIndex = 74;
            this.label2.Text = "Thể loại:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(139, 122);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(55, 13);
            this.label1.TabIndex = 73;
            this.label1.Text = "Tên sách:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label6.Location = new System.Drawing.Point(247, 88);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(244, 13);
            this.label6.TabIndex = 96;
            this.label6.Text = "(Cập nhật theo mã sách, vui lòng nhập chính xác)";
            // 
            // CapNhatSach
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(684, 461);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.bt_thoat);
            this.Controls.Add(this.bt_capNhat);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.tb_maSach);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.tb_soLuong);
            this.Controls.Add(this.cb_theLoai);
            this.Controls.Add(this.tb_tinhTrang);
            this.Controls.Add(this.tb_triGia);
            this.Controls.Add(this.tb_nhaXuatBan);
            this.Controls.Add(this.tb_namXuatBan);
            this.Controls.Add(this.tb_tacGia);
            this.Controls.Add(this.tb_tenSach);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.MaximumSize = new System.Drawing.Size(700, 500);
            this.MinimumSize = new System.Drawing.Size(700, 500);
            this.Name = "CapNhatSach";
            this.Text = "Cập nhật sách";
            this.Load += new System.EventHandler(this.CapNhatSach_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button bt_thoat;
        private System.Windows.Forms.Button bt_capNhat;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox tb_maSach;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox tb_soLuong;
        private System.Windows.Forms.ComboBox cb_theLoai;
        private System.Windows.Forms.TextBox tb_tinhTrang;
        private System.Windows.Forms.TextBox tb_triGia;
        private System.Windows.Forms.TextBox tb_nhaXuatBan;
        private System.Windows.Forms.TextBox tb_namXuatBan;
        private System.Windows.Forms.TextBox tb_tacGia;
        private System.Windows.Forms.TextBox tb_tenSach;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label6;
    }
}