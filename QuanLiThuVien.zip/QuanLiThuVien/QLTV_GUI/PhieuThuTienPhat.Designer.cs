﻿namespace QLTV_GUI
{
    partial class PhieuThuTienPhat
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.bt_thoat = new System.Windows.Forms.Button();
            this.bt_xacNhan = new System.Windows.Forms.Button();
            this.tb_conLai = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.tb_soTienThu = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.tb_tongNo = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.cb_hoTenDocGia = new System.Windows.Forms.ComboBox();
            this.SuspendLayout();
            // 
            // bt_thoat
            // 
            this.bt_thoat.BackColor = System.Drawing.Color.Tomato;
            this.bt_thoat.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.bt_thoat.ForeColor = System.Drawing.SystemColors.Control;
            this.bt_thoat.Location = new System.Drawing.Point(357, 169);
            this.bt_thoat.Name = "bt_thoat";
            this.bt_thoat.Size = new System.Drawing.Size(110, 50);
            this.bt_thoat.TabIndex = 70;
            this.bt_thoat.Text = "THOÁT";
            this.bt_thoat.UseVisualStyleBackColor = false;
            // 
            // bt_xacNhan
            // 
            this.bt_xacNhan.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.bt_xacNhan.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.bt_xacNhan.ForeColor = System.Drawing.SystemColors.Control;
            this.bt_xacNhan.Location = new System.Drawing.Point(221, 169);
            this.bt_xacNhan.Name = "bt_xacNhan";
            this.bt_xacNhan.Size = new System.Drawing.Size(110, 50);
            this.bt_xacNhan.TabIndex = 69;
            this.bt_xacNhan.Text = "XÁC NHẬN";
            this.bt_xacNhan.UseVisualStyleBackColor = false;
            // 
            // tb_conLai
            // 
            this.tb_conLai.Location = new System.Drawing.Point(473, 112);
            this.tb_conLai.Name = "tb_conLai";
            this.tb_conLai.Size = new System.Drawing.Size(162, 20);
            this.tb_conLai.TabIndex = 68;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(417, 115);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(42, 13);
            this.label5.TabIndex = 67;
            this.label5.Text = "Còn lại:";
            // 
            // tb_soTienThu
            // 
            this.tb_soTienThu.Location = new System.Drawing.Point(206, 109);
            this.tb_soTienThu.Name = "tb_soTienThu";
            this.tb_soTienThu.Size = new System.Drawing.Size(162, 20);
            this.tb_soTienThu.TabIndex = 66;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(49, 112);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(61, 13);
            this.label3.TabIndex = 65;
            this.label3.Text = "Số tiền thu:";
            // 
            // tb_tongNo
            // 
            this.tb_tongNo.Location = new System.Drawing.Point(473, 69);
            this.tb_tongNo.Name = "tb_tongNo";
            this.tb_tongNo.Size = new System.Drawing.Size(162, 20);
            this.tb_tongNo.TabIndex = 64;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(417, 72);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(50, 13);
            this.label2.TabIndex = 63;
            this.label2.Text = "Tổng nợ:";
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(105, 69);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(0, 20);
            this.textBox1.TabIndex = 62;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(49, 72);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(47, 13);
            this.label1.TabIndex = 61;
            this.label1.Text = "Độc giả:";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label11.ForeColor = System.Drawing.SystemColors.MenuHighlight;
            this.label11.Location = new System.Drawing.Point(159, 18);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(370, 31);
            this.label11.TabIndex = 60;
            this.label11.Text = "LẬP PHIẾU THU TIỀN PHẠT";
            // 
            // cb_hoTenDocGia
            // 
            this.cb_hoTenDocGia.FormattingEnabled = true;
            this.cb_hoTenDocGia.Location = new System.Drawing.Point(105, 69);
            this.cb_hoTenDocGia.Name = "cb_hoTenDocGia";
            this.cb_hoTenDocGia.Size = new System.Drawing.Size(263, 21);
            this.cb_hoTenDocGia.TabIndex = 71;
            // 
            // PhieuThuTienPhat
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(684, 236);
            this.Controls.Add(this.cb_hoTenDocGia);
            this.Controls.Add(this.bt_thoat);
            this.Controls.Add(this.bt_xacNhan);
            this.Controls.Add(this.tb_conLai);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.tb_soTienThu);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.tb_tongNo);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.label11);
            this.MaximumSize = new System.Drawing.Size(700, 275);
            this.MinimumSize = new System.Drawing.Size(700, 275);
            this.Name = "PhieuThuTienPhat";
            this.Text = "Phiếu thu tiền phạt";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button bt_thoat;
        private System.Windows.Forms.Button bt_xacNhan;
        private System.Windows.Forms.TextBox tb_conLai;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox tb_soTienThu;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox tb_tongNo;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.ComboBox cb_hoTenDocGia;
    }
}